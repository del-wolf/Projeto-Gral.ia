# Gral.ia — entrega testável

Versão 0.1.0, consolidada em 16/11/2026. Abra a pasta `Gralia` no VS Code, instale Node 24 LTS e execute `npm ci` e `npm run dev`. Acesse `http://127.0.0.1:5173`. A demo não exige conta externa, chave de API ou Docker. Consulte o README para PowerShell, perfis fictícios, reset e todos os comandos.

Implementados: entrada/saída simuladas, temas, home por perfil, acesso negado, cadastros acadêmicos, catálogo/turmas/períodos/ofertas, matrícula em lote, área aluno/professor, avaliações/notas decimais, aulas/frequência, materiais por link, agenda derivada e salas/reservas. A persistência local é versionada, confirma gravação e possui reset com confirmação. Adaptador Supabase Auth/Data API, migração PostgreSQL, RLS/grants, RPCs, provisionamento local e suítes integradas foram escritos.

## Resultados observados

| Verificação | Resultado e evidência |
|---|---|
| TypeScript, ESLint, builds demo/Supabase e inspeção do bundle integrado | Aprovados — `docs/evidencias/2026-11-16T05-48-13-722Z-checks/` |
| Vitest | 36/36 aprovados no mesmo diretório; regras/repositório demo e adaptador SDK simulado |
| Cypress demo | 15/15 aprovados, sem pendentes ou ignorados — `docs/evidencias/2026-11-16-demo-final/`; CT-GR-001/002 com 14 campos, capturas reais, consulta independente e recarga |
| PostgreSQL 17.6 descartável | 44/44 aprovados — `docs/evidencias/db-2026-11-16T05-40-42-834Z/`; RLS com cinco sujeitos simulados, integridade e duas conexões concorrentes reais |
| Guardas da preparação integrada | 10 aprovadas, sem conexão — `docs/evidencias/supabase-e2e-bloqueado-2026-11-16T05-49-10.751Z/` |

As tentativas anteriores com falhas foram preservadas. O relatório final de navegador identifica o snapshot por hash e distingue asserções da UI, domínio e backend. As notas/frequências são convenções demonstrativas; o aplicativo não substitui registros oficiais.

## Limites e próximo passo

Supabase Auth/GoTrue, JWT assinado, API HTTP e E2E integrado ficaram **BLOQUEADOS**: a stack local completa excedeu o espaço disponível para imagens Docker. PostgreSQL/RLS aprovado não aprova esses ensaios. O código e as instruções de reprodução estão em `supabase/README.md` e `docs/TESTES_SUPABASE_E2E.md`. O próximo passo é executar a stack descartável em máquina com espaço suficiente, provisionar as cinco contas sintéticas e executar as suítes HTTP e Cypress integradas.

Windows/VS Code, leitor de tela, zoom manual de 200%, GitHub Actions remoto, Android/APK e publicação não foram executados. O fluxo web foi executado em Linux/Electron. Axe, teclado automatizado, reflow 320 px e contraste estático não certificam conformidade integral WCAG/eMAG. A demo não coordena gravações entre abas. Consulte `docs/STATUS_IMPLEMENTACAO.md` e `docs/VALIDACAO.md`.

Este pacote preserva apenas dados sintéticos, não inclui o CSV pessoal, credenciais ou node_modules. Inclui código, lockfile, builds, documentação e evidências. `MANIFESTO_SHA256.json` identifica os bytes de cada arquivo distribuído.
