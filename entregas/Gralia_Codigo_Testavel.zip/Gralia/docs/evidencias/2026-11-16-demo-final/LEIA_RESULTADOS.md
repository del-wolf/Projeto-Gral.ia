# Execução final da demonstração

Resultado observado: **15/15 testes aprovados**, 0 falhas, 0 pendentes e 0 ignorados. Duração informada pelo Cypress: 42.06 segundos.

Modo: demo local com localStorage, fixture 1.0. Navegador electron 138.0.7204.251; Cypress 15.21.2; Node v24.22.1; linux. Relógio da aplicação nos testes: `2026-11-16T12:00:00Z`.

As verificações comprovam os cenários automatizados abaixo. Não comprovam Supabase/Auth remotos, Windows, APK, leitor de tela, zoom físico de 200% ou conformidade integral WCAG/eMAG. Os IDs agrupados indicam os aspectos exercitados e não aprovação automática de todos os passos manuais dos 41 casos planejados.

| Cenário executado | Observado |
|---|---|
| CT-GR-001 matrícula válida: persiste exatamente um vínculo e limpa a seleção | passed |
| CT-GR-002 nenhuma oferta: botão desabilitado, ajuda e zero chamadas de criação | passed |
| CT-GR-004 e CT-GR-005 mudança da busca invalida aluno e seleção anteriores | passed |
| CT-GR-034 erro de armazenamento preserva formulário e não anuncia sucesso | passed |
| CT-GR-006 e CT-GR-027 aluno recebe acesso negado ao endereço admin e logout encerra sessão | passed |
| CT-GR-029 aluno A e B recebem apenas as próprias ofertas | passed |
| CT-GR-004 respostas invertidas não restauram um aluno obsoleto | passed |
| CT-GR-013/015 zero completa a média e a nota decimal persiste após recarga | passed |
| CT-GR-017/018 professor lança presença pendente sem duplicar registros | passed |
| CT-GR-020/041 material e avaliação aparecem na oferta do aluno correto | passed |
| CT-GR-021/022/023/025 reserva persiste, rejeita conflito, permite adjacência e cancela | passed |
| CT-GR-035/037 reset confirma, preserva outras chaves e devolve foco ao cancelar | passed |
| CT-GR-038 reflow 320px mantém matrícula operável | passed |
| CT-GR-039 axe verifica entrada e matrícula nos temas claro e escuro | passed |
| CT-GR-036/037 teclado opera entrada, matrícula, skip link e foco do modal | passed |

## Evidências

- [Ambiente, horário com fuso e SHA-256 da fonte](ambiente.json).
- [Relatório JSON efetivo](cypress-results.json), [JUnit](cypress-junit.xml) e [log](cypress.log).
- [CT-GR-001 — esperado separado do observado, 14 campos](CT-GR-001/resultado-observado.json).
- [CT-GR-002 — esperado separado do observado, 14 campos](CT-GR-002/resultado-observado.json).
- Capturas reais em `screenshots/demo.cy.ts/` e `screenshots/keyboard.cy.ts/`.
- CT-GR-002 comprova zero chamadas originadas da UI; a rejeição da entrada vazia pelo domínio é testada separadamente por Vitest. A RPC real requer a execução integrada própria.

As rodadas anteriores permanecem preservadas. O diagnóstico do ensaio de teclado está em `../2026-11-16-keyboard-focused/diagnostico-harness.md`. O ensaio final mantém Space nativo para ativar botões, sem force ou substituição por clique.
