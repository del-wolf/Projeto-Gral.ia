"""Cálculo estático WCAG de pares de cores selecionados do CSS, sem inspeção visual."""
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import hashlib
import json
import re

root = Path(__file__).resolve().parents[3]
source = root / 'app/src/styles.css'
css = source.read_text()

def variables(selector):
    body = re.search(re.escape(selector) + r'\{([^}]*)\}', css)
    if body is None:
        raise RuntimeError('Seletor ausente: ' + selector)
    return dict(re.findall(r'(--[\w-]+):([^;}]+)', body.group(1)))

light = variables(':root')
dark = light | variables('[data-theme=dark]')
border = re.findall(r'input,select,textarea\{border-color:(#[0-9a-fA-F]{6})\}', css)
dark_avatar = re.findall(r'\[data-theme=dark\] \.room-symbol\{color:(#[0-9a-fA-F]{6})\}', css)
if not border or not dark_avatar:
    raise RuntimeError('Overrides de borda e texto escuro não localizados; revisar seletores no script.')

def luminance(color):
    if len(color) == 4:
        color = '#' + ''.join(character * 2 for character in color[1:])
    channels = [int(color[index:index + 2], 16) / 255 for index in (1, 3, 5)]
    linear = [value / 12.92 if value <= .04045 else ((value + .055) / 1.055) ** 2.4 for value in channels]
    return sum(value * coefficient for value, coefficient in zip(linear, (.2126, .7152, .0722)))

def contrast(first, second):
    low, high = sorted((luminance(first), luminance(second)))
    return (high + .05) / (low + .05)

pairs = []
for name, theme in (('claro', light), ('escuro', dark)):
    pairs.extend([
        (name, 'Texto principal / superfície', theme['--text'], theme['--surface'], 4.5),
        (name, 'Texto secundário / superfície', theme['--muted'], theme['--surface'], 4.5),
        (name, 'Texto secundário / fundo', theme['--muted'], theme['--bg'], 4.5),
        (name, 'Texto secundário / superfície suave', theme['--muted'], theme['--soft'], 4.5),
        (name, 'Texto branco / botão primário', '#ffffff', theme['--primary'], 4.5),
        (name, 'Borda de campo / superfície', border[-1], theme['--surface'], 3),
        (name, 'Foco / superfície', theme['--focus'], theme['--surface'], 3),
        (name, 'Iniciais e etapa / superfície suave', dark_avatar[-1] if name == 'escuro' else theme['--primary'], theme['--soft'], 4.5),
    ])
pairs.extend([
    ('ambos', 'Aviso demo', '#193a59', '#e6eff8', 4.5),
    ('ambos', 'Aviso offline', '#47370c', '#fff0c4', 4.5),
    ('ambos', 'Link primário navegação lateral', '#c4d3e2', '#102a43', 4.5),
    ('ambos', 'Texto secundário hero', '#c1d5e5', '#123854', 4.5),
    ('claro', 'Erro / superfície', light['--danger'], light['--surface'], 4.5),
    ('escuro', 'Erro / superfície', '#ffc4ca', dark['--surface'], 4.5),
    ('claro', 'Sucesso / superfície', light['--success'], light['--surface'], 4.5),
    ('escuro', 'Sucesso / superfície', dark['--success'], dark['--surface'], 4.5),
])
results = []
for name, label, foreground, background, minimum in pairs:
    ratio = contrast(foreground, background)
    results.append({'tema': name, 'par': label, 'primeira_cor': foreground, 'segunda_cor': background,
                    'razao': round(ratio, 4), 'minimo_aplicado': minimum,
                    'resultado_calculo': 'APROVADO' if ratio >= minimum else 'REPROVADO'})
now = datetime.now(timezone.utc)
report = {
    'tipo': 'CALCULO_ESTATICO_DE_PARES_CSS',
    'utc': now.isoformat(),
    'america_sao_paulo': now.astimezone(ZoneInfo('America/Sao_Paulo')).isoformat(),
    'arquivo': 'app/src/styles.css',
    'sha256_css': hashlib.sha256(source.read_bytes()).hexdigest(),
    'metodo': 'Luminância relativa sRGB WCAG: (Lmaior + 0.05) / (Lmenor + 0.05).',
    'escopo': 'Pares opacos selecionados do CSS e limiares indicados; não é auditoria do navegador.',
    'limites': ['Não mede renderização, antialiasing, mistura alfa, texto sobre imagens, hover ou todos os componentes.',
                'Não comprova teclado, leitor de tela, reflow, zoom, foco real ou conformidade integral WCAG/eMAG.',
                'Os limiares de borda/foco são aplicados aos pares selecionados; geometria e demais critérios exigem inspeção.'],
    'resultados': results,
    'pares': len(results),
    'reprovados': sum(item['resultado_calculo'] == 'REPROVADO' for item in results),
}
output = Path(__file__).with_name('resultado.json')
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'pares': report['pares'], 'reprovados': report['reprovados'], 'sha256_css': report['sha256_css']}, ensure_ascii=False))
raise SystemExit(1 if report['reprovados'] else 0)
