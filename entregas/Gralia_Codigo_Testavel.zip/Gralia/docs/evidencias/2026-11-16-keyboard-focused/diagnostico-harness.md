# Diagnóstico do ensaio de teclado

Ambiente observado: Cypress 15.21.2, Electron 138 headless, Linux/Xvfb.

Na rodada v6, a captura de falha mostra OF-TEST-3A selecionada e o botão Registrar matrícula habilitado e focado. O comando Cypress `.type("{enter}")` não acionou o `onClick` delegado do React no botão fora de formulário. A falha foi preservada na rodada v6; não foi tratada como aprovação.

O runner efetivamente instalado contém o trecho abaixo nas linhas 116179–116185. O `PointerEvent` sintético não define `bubbles: true`; o valor padrão é falso. O caminho de submissão de formulário é separado. Isso explica por que a emulação `.type` podia submeter a entrada, mas não acionar o botão fora da form.

```js
      const fireClickEvent = el => {
        const ctor = _dom__WEBPACK_IMPORTED_MODULE_2__["default"].getDocumentFromElement(el).defaultView.PointerEvent;
        const event = new ctor('click', {
          composed: true
        });
        el.dispatchEvent(event);
      };
```

SHA-256 do runner inspecionado: `a15e60d02d0083be45c178bd8ce34df885777cdf5dccf56bf7bea8ccc45bbfaa`. Referência de implementação: https://github.com/cypress-io/cypress/blob/develop/packages/driver/src/cy/commands/actions/type.ts

O ensaio final usa `cy.press(SPACE)` nativo para ativar botões, uma ação padrão de teclado válida. Mantém Enter nativo em links, Tab, Escape e Space na caixa de seleção; a submissão da entrada por Enter usa a emulação de formulário do Cypress. Nenhuma ação usa `force`, `.click()` substituindo tecla ou exclusão de assertion. O ensaio focado passou 1/1 e preservou captura e relatórios nesta pasta. Isso não substitui ensaio manual com teclado físico ou leitor de tela.
